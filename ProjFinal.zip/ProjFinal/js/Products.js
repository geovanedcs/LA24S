export class Products{
    constructor(name, price, amout, description, image){
        this.name = name;
        this.price = price;
        this.amout = amout;
        this.description = description;
        this.image = image;
    }
}